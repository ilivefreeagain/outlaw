# esx_outlawalert

script originally from here: https://forum.fivem.net/t/release-simple-outlaw-alert-11-04-2017/9383

made it esx compatibe. shows alert to cops when shooting, carjacking car or fighting.
